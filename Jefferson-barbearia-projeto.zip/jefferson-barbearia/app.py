import os, secrets, hmac
from datetime import datetime, timezone
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, abort
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import check_password_hash

app = Flask(__name__)
app.config.update(SECRET_KEY=os.environ.get('SECRET_KEY', secrets.token_hex(32)),SQLALCHEMY_DATABASE_URI=os.environ.get('DATABASE_URL','sqlite:///barbearia.db').replace('postgres://','postgresql://',1),SQLALCHEMY_TRACK_MODIFICATIONS=False,SESSION_COOKIE_HTTPONLY=True,SESSION_COOKIE_SAMESITE='Lax',SESSION_COOKIE_SECURE=os.getenv('COOKIE_SECURE','1')=='1')
db=SQLAlchemy(app)
class Service(db.Model):
 id=db.Column(db.Integer,primary_key=True)
 name=db.Column(db.String(100),nullable=False)
 price=db.Column(db.Numeric(9,2),nullable=False)
 duration=db.Column(db.Integer,default=30)
 active=db.Column(db.Boolean,default=True)
class Ticket(db.Model):
 id=db.Column(db.Integer,primary_key=True)
 name=db.Column(db.String(100),nullable=False)
 service_id=db.Column(db.Integer,db.ForeignKey('service.id'),nullable=False)
 service=db.relationship('Service')
 status=db.Column(db.String(20),default='waiting')
 payment=db.Column(db.String(20),default='pending')
 token=db.Column(db.String(60),unique=True,default=lambda:secrets.token_urlsafe(30))
 created=db.Column(db.DateTime,default=lambda:datetime.now(timezone.utc))
with app.app_context():
 db.create_all()
 if not Service.query.first():
  db.session.add_all([Service(name=n,price=p,duration=d) for n,p,d in [('Corte de cabelo',30,30),('Barba',20,20),('Corte e barba',45,45),('Pezinho',10,10),('Sobrancelha',10,10)]])
  db.session.commit()
def csrf():
 if 'csrf' not in session:session['csrf']=secrets.token_urlsafe(24)
 return session['csrf']
def verify():
 if not hmac.compare_digest(str(request.form.get('csrf','')),str(session.get('csrf','undefined'))):abort(400)
def admin_required(fn):
 @wraps(fn)
 def f(*a,**kw):
  if not session.get('admin'):return redirect(url_for('login'))
  return fn(*a,**kw)
 return f
@app.context_processor
def shared():return dict(csrf_token=csrf(),pix_key=os.getenv('PIX_KEY',''))
@app.get('/health')
def health():return {'ok':True}
@app.get('/')
def index():return render_template('index.html',services=Service.query.filter_by(active=True).all())
@app.post('/join')
def join():
 verify();name=request.form.get('name','').strip()
 if not 2<=len(name)<=100:abort(400)
 try:sid=int(request.form.get('service_id',''))
 except ValueError:abort(400)
 s=db.session.get(Service,sid)
 if not s or not s.active:abort(400)
 t=Ticket(name=name,service_id=sid);db.session.add(t);db.session.commit()
 return redirect(url_for('ticket',token=t.token))
@app.get('/ticket/<token>')
def ticket(token):
 t=Ticket.query.filter_by(token=token).first_or_404()
 ahead=Ticket.query.filter(Ticket.id<t.id,Ticket.status.in_(['waiting','serving'])).count() if t.status=='waiting' else 0
 return render_template('ticket.html',t=t,ahead=ahead)
@app.route('/login',methods=['GET','POST'])
def login():
 error=False
 if request.method=='POST':
  verify();user=os.getenv('ADMIN_USER','');ph=os.getenv('ADMIN_PASSWORD_HASH','')
  if user and ph and hmac.compare_digest(user,request.form.get('username','')) and check_password_hash(ph,request.form.get('password','')):
   session.clear();session['admin']=True;return redirect(url_for('admin'))
  error=True
 return render_template('login.html',error=error)
@app.get('/admin')
@admin_required
def admin():
 tickets=Ticket.query.order_by(Ticket.id.desc()).limit(200).all()
 return render_template('admin.html',tickets=tickets,services=Service.query.order_by(Service.id).all(),waiting=Ticket.query.filter_by(status='waiting').count(),serving=Ticket.query.filter_by(status='serving').count())
@app.post('/admin/ticket/<int:tid>')
@admin_required
def update_ticket(tid):
 verify();t=db.session.get(Ticket,tid)
 if not t:abort(404)
 action=request.form.get('action')
 if action=='paid':t.payment='paid'
 elif action in ('waiting','serving','done','cancelled'):t.status=action
 else:abort(400)
 db.session.commit();return redirect(url_for('admin'))
@app.post('/admin/service')
@admin_required
def add_service():
 verify()
 from decimal import Decimal,InvalidOperation
 try:
  name=request.form.get('name','').strip();price=Decimal(request.form.get('price',''));duration=int(request.form.get('duration',''))
  if not 1<=len(name)<=100 or not 0<=price<=99999 or not 5<=duration<=480:abort(400)
 except (InvalidOperation,ValueError):abort(400)
 db.session.add(Service(name=name,price=price,duration=duration));db.session.commit();return redirect(url_for('admin'))
@app.post('/admin/service/<int:sid>/toggle')
@admin_required
def toggle(sid):
 verify();s=db.session.get(Service,sid)
 if not s:abort(404)
 s.active=not s.active;db.session.commit();return redirect(url_for('admin'))
@app.post('/logout')
@admin_required
def logout():verify();session.clear();return redirect(url_for('login'))
if __name__=='__main__':app.run(host='0.0.0.0',port=int(os.environ.get('PORT',5000)))
