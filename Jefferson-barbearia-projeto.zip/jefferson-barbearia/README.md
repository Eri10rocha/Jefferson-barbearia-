# Jefferson Barbearia

Sistema web para fila de espera, painel de barbeiro, serviços e chave Pix. **QR Code é um link para entrada na fila, não um QR Pix de cobrança**. A confirmação do pagamento é manual. A página do cliente não exige login; o painel exige senha.

## Executar localmente

```bash
python -m venv .venv
pip install -r requirements.txt
# configure SECRET_KEY, ADMIN_USER, ADMIN_PASSWORD_HASH, PIX_KEY e DATABASE_URL
python app.py
```

Para gerar o hash da senha do administrador, execute localmente:

```bash
python -c "from werkzeug.security import generate_password_hash; import getpass; print(generate_password_hash(getpass.getpass('Nova senha: ')))"
```

## Publicar no Render

1. Envie os arquivos para este repositório (mantenha `.env` fora do Git).
2. Crie um banco PostgreSQL no Render, escolhendo uma opção apropriada de persistência e retenção. O banco local SQLite NÃO deve ser usado no web service, porque o filesystem é efêmero.
3. Crie um Web Service Python para este repositório, branch `main`. Build: `pip install -r requirements.txt`; Start: `gunicorn app:app`; rota de health: `/health`.
4. Configure as variáveis SECRET_KEY, ADMIN_USER, ADMIN_PASSWORD_HASH, PIX_KEY, DATABASE_URL e COOKIE_SECURE=1 pelo painel Render.
5. Teste `/health`, `/`, `/login`, cadastro na fila e painel. Não publique senha, hash, chave Pix ou conexão de banco em README ou commits.

**Limitações desta versão inicial:** não integra cobrança automática Pix, não inclui horários de agenda/calendário, cadastro avançado de usuários, comprovantes ou notificações. Não considere esta versão um sistema financeiro ou de agendamento completo.
